# StreamLit
Streamlit APP Bank
This is my first Streamlit app that uses machine learning to classify the risk of loan applicants.
It is available here: <a href="https://sebastiansosa-streamlit-app-nm6256.streamlit.app/" class="button big">APP</a>
